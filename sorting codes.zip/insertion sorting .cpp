
#include <iostream>
using namespace std;

// Function to perform insertion sort
void insertionSort(int arr[], int n) {
    for (int i = 1; i < n; i++) { // Start from the second element (index 1)
        int key = arr[i];  // The element to be inserted into the sorted part of the array
        int j = i - 1;

        // Shift elements of the sorted part that are greater than key to one position ahead
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];  // Move element to the next position
            j--;
        }
        arr[j + 1] = key;  // Insert the key element into its correct position
    }
}

// Function to print the array
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    int arr[] = {64, 34, 25, 12, 22, 11, 90};  // Example array
    int size = sizeof(arr) / sizeof(arr[0]);

    cout << "Given array: ";
    printArray(arr, size);

    insertionSort(arr, size);  // Sorting the array using insertion sort

    cout << "Sorted array: ";
    printArray(arr, size);

    return 0;
    }